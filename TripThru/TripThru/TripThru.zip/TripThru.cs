﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using APIs;
using Simulations;
using Utils;
namespace tripThru
{
    public class TripThru : Gateway
    {
        public class Partner : IDName
        {
            public Gateway callback_url;
            public Partner(string name, Gateway callback_url)
                : base(name)
            {
                this.callback_url = callback_url;
            }
        }
        public List<Partner> partners;
        public Dictionary<string, Partner> partnersByID;
        public Dictionary<string, string> tripPartnerMap;
        public TripThru()
        {
            partnersByID = new Dictionary<string, Partner>();
            tripPartnerMap = new Dictionary<string, string>();
            registerPartner = new RegisterPartner(this);
            getPartnerInfo = new GetPartnerInfo(this);
            dispatchTrip = new DispatchTrip(this);
            quoteTrip = new QuoteTrip(this);
            getTripStatus = new GetTripStatus(this);
            updateTripStatus = new UpdateTripStatus(this);

            partners = new List<Partner>();
        }
        public void AddPartner(Partner partner)
        {
            partners.Add(partner);
            partnersByID.Add(partner.ID, partner);
        }

        public new class RegisterPartner : Gateway.RegisterPartner
        {
            public TripThru tripthru;
            public RegisterPartner(TripThru tripthru)
            {
                this.tripthru = tripthru;
            }
            public override Response Post(Request r)
            {
                Partner partner = new Partner(r.name, r.callback_url);
                tripthru.AddPartner(partner);
                Response response = new Response(partner.ID);
                Logger.Log("Registering partner: " + partner.name + " with TripThru, Response: " + response);
                return response;
            }
        }
        public new class GetPartnerInfo : Gateway.GetPartnerInfo
        {
            public TripThru tripthru;
            public GetPartnerInfo(TripThru tripthru)
            {
                this.tripthru = tripthru;
            }
            public override Response Get(Request r)
            {
                if (r.fleets != null || r.vehicleTypes != null || r.coverage != null)
                    throw new Exception("Filters currently not supported");
                List<VehicleType> vehicleTypes = new List<VehicleType>();
                List<Response.Fleet> fleets = new List<Response.Fleet>();
                foreach (Partner p in tripthru.partners)
                {
                    Response response = p.callback_url.getPartnerInfo.Get(r);
                    fleets.AddRange(response.fleets);
                    vehicleTypes.AddRange(response.vehicleTypes);
                }
                Response resp = new Response(fleets, vehicleTypes);
                Logger.Log("GetPartnerInfo called on TripThru, Response: " + resp);
                return resp;

            }
        }
        public new class DispatchTrip : Gateway.DispatchTrip
        {
            public TripThru tripthru;
            public DispatchTrip(TripThru tripthru)
            {
                this.tripthru = tripthru;
            }
            public override Response Post(Request r)
            {
                // Note: GetTrip populates the foreignTripID
                Logger.Log("DispatchTrip called on TripThru");
                Logger.Tab();
                Partner partner;
                if (r.partnerID == null)
                {
                    Logger.Log("DispatchTrip called on TripThru: (auto) mode, so quote trip through all partners");
                    Logger.Tab();
                    // Dispatch to partner with shortest ETA
                    QuoteTrip.Response response = tripthru.quoteTrip.Get(new QuoteTrip.Request(
                        clientID:"tripthru", // TODO: Daniel, fix this when you add authentication
                        pickupLocation: r.pickupLocation,
                        pickupTime: r.pickupTime,
                        passengerID: r.passengerID,
                        passengerName: r.passengerName,
                        luggage: r.luggage,
                        persons: r.persons,
                        dropoffLocation: r.dropoffLocation,
                        waypoints: r.waypoints,
                        paymentMethod: r.paymentMethod,
                        vehicleType: r.vehicleType,
                        maxPrice: r.maxPrice,
                        minRating: r.minRating,
                        partnerID: r.partnerID,
                        fleetID: r.fleetID,
                        driverID: r.driverID));
                    if (response.result == Result.Rejected)
                    {
                        Logger.Log("No partners are available");
                        return new Response(result: Result.Rejected);
                    }
                    else
                    {
                        QuoteTrip.Response.Quote bestQuote = null;
                        DateTime bestETA = DateTime.MaxValue;
                        foreach (QuoteTrip.Response.Quote q in response.quotes)
                        {
                            if (q.ETA < bestETA)
                            {
                                bestETA = (DateTime) q.ETA;
                                bestQuote = q;
                            }
                        }
                        partner = tripthru.partnersByID[bestQuote.partnerID];
                        r.fleetID = bestQuote.fleetID;
                        Logger.Log("Dispatch to best quote " + bestQuote);
                    }
                    Logger.Untab();
                }
                else
                    partner = tripthru.partnersByID[r.partnerID];
                Response response1 = partner.callback_url.dispatchTrip.Post(r);
                if (response1.result == Result.OK)
                {
                    tripthru.tripPartnerMap.Add(response1.tripID, partner.ID);
                    tripthru.tripPartnerMap.Add(r.foreignID, r.clientID);
                }
                Logger.Untab();
                Logger.Log("Response: " + response1);
                return response1;
            }
        }
        public new class QuoteTrip : Gateway.QuoteTrip
        {
            public TripThru tripthru;
            public QuoteTrip(TripThru tripthru)
            {
                this.tripthru = tripthru;
            }
            public override Response Get(Request r)
            {
                Logger.Log("QuoteTrip called on TripThru");
                Logger.Tab();
                List<Response.Quote> quotes = new List<Response.Quote>();

                foreach (Partner p in tripthru.partners)
                {
                    Response response = p.callback_url.quoteTrip.Get(r);
                    quotes.AddRange(response.quotes);

                }
                Response response1 = new Response(quotes);
                Logger.Untab();
                Logger.Log("Response: " + response1);

                return response1;
            }
        }
        public new class GetTripStatus : Gateway.GetTripStatus
        {
            public TripThru tripthru;
            public GetTripStatus(TripThru tripthru)
            {
                this.tripthru = tripthru;
            }
            public override Response Get(Request r)
            {
                Partner partner = tripthru.partnersByID[tripthru.tripPartnerMap[r.tripID]];
                Response response = partner.callback_url.getTripStatus.Get(r);
                response.partnerID = partner.ID;
                response.partnerName = partner.name;
                return response;
            }
        }
        public new class UpdateTripStatus : Gateway.UpdateTripStatus
        {
            public TripThru tripthru;
            public UpdateTripStatus(TripThru tripthru)
            {
                this.tripthru = tripthru;
            }
            public override Response Post(Request r)
            {
                // Note: GetTrip populates the foreignTripID
                Partner partner = tripthru.partnersByID[tripthru.tripPartnerMap[r.tripID]];
                Logger.Log("Forwarding request to " + partner.name);
                return partner.callback_url.updateTripStatus.Post(r);
            }
        }
    }
}

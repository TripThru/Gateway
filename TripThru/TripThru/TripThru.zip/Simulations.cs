﻿using System;
using System.Reflection;
using System.Collections.Generic;
using System.Linq;
using System.Text;
// local
using APIs;
using Utils;

namespace Simulations
{
    // a route consists of waypoints that are 5 mins apart.
    public class Trip : IDName
    {
        public Status status { get { return _status; } }
        public enum Origination { Local, Foreign };
        public void SetStatus(Status value, bool notifyPartner = true)
        {
            if (_status != value)
            {
                Logger.Log("Trip status changed from " + _status + " to " + value);
                _status = value;
                if (foreignID != null && notifyPartner)
                {
                    Logger.Log("Since trip originated elsewhere, notify originating partner through TripThru");
                    Logger.Tab();
                    Gateway.UpdateTripStatus.Request request = new Gateway.UpdateTripStatus.Request(
                        clientID: partner.foreignID,
                        tripID: foreignID, 
                        status: value);
                    partner.tripthru.updateTripStatus.Post(request);
                    Logger.Untab();
                }
            }
        }

        private Status _status;
        public string passengerID;
        public string passengerName;
        public string foreignID;
        public Origination origination;
        public int? luggage;
        public int? persons;
        public Location pickupLocation;
        public DateTime pickupTime;
        public TimeSpan? duration;
        public Location dropoffLocation;
        public DateTime? dropoffTime;
        public Location[] waypoints;
        public PaymentMethod? paymentMethod;
        public VehicleType? vehicleType;
        public double? maxPrice;
        public int? minRating;
        public Fleet fleet;
        public Driver driver;
        public DateTime lastUpdate;
        public Partner partner;
        public Trip(Trip t)
        {
            this.ID = t.ID;
            this.passengerID = t.passengerID;
            this.passengerName = t.passengerName;
            this.foreignID = t.foreignID;
            this.origination = t.origination;
            this.luggage = t.luggage;
            this.persons = t.persons;
            this.pickupLocation = t.pickupLocation;
            this.pickupTime = t.pickupTime;
            this.duration = t.duration;
            this.dropoffLocation = t.dropoffLocation;
            this.dropoffTime = t.dropoffTime;
            this.waypoints = t.waypoints;
            this.paymentMethod = t.paymentMethod;
            this.vehicleType = t.vehicleType;
            this.maxPrice = t.maxPrice;
            this.minRating = t.minRating;
            this.fleet = t.fleet;
            this.driver = t.driver;
            this.lastUpdate = t.lastUpdate;
            this._status = t._status;
            this.partner = t.partner;
        }
        public override string ToString()
        {
            string s = "Trip" + ID;
            s += ", Status = " + status;
            if (foreignID != null)
            {
                if (origination == Origination.Local)
                    s += ", Origination = Local, Service = Foreign (ID = " + foreignID + ")";
                else if (origination == Origination.Foreign)
                    s += ", Origination = Foreign (ID = " + foreignID + "), Service = Local";
            }
            else
                s += ", Origination/Service = Local";
            s += ", PickupLocation = " + pickupLocation;
            s += ", PickupTime = " + pickupTime;
            if (passengerName != null)
                s += ", Passenger = " + passengerName;
            if (dropoffLocation != null)
                s += ", DropoffLocation = " + dropoffLocation;
            if (dropoffTime != null)
                s += ", DropoffTime = " + dropoffTime;
            if (fleet != null)
                s += ", Fleet = " + fleet.name;
            if (driver != null)
                s += ", Driver = " + driver;

            return s;
        }
        public Trip(Partner partner, Location pickupLocation, DateTime pickupTime, PaymentMethod? paymentMethod = null, string passengerID = null, string passengerName = null, Location dropoffLocation = null,
            DateTime? dropoffTime = null, Location[] waypoints = null, VehicleType? vehicleType = null, double? maxPrice = null, int? minRating = null, Fleet fleet = null, Driver driver = null, string foreignID = null, TimeSpan? duration = null)
        {
            this.ID = GenerateUniqueID();
            if (foreignID != null)
            {
                this.foreignID = foreignID;
                this.origination = Origination.Foreign;
            }
            else
                this.origination = Origination.Local;
            this.partner = partner;
            this.passengerID = passengerID;
            this.passengerName = passengerName;
            this.pickupLocation = pickupLocation;
            this.pickupTime = pickupTime;
            this.duration = duration;
            this.dropoffLocation = dropoffLocation;
            this.dropoffTime = dropoffTime;
            this.waypoints = waypoints;
            this.paymentMethod = paymentMethod;
            this.vehicleType = vehicleType;
            this.maxPrice = maxPrice;
            this.minRating = minRating;
            this.fleet = fleet;
            this.driver = driver;
            this.SetStatus(Status.Queued, notifyPartner: false);
        }
    }
    public class Passenger : IDName
    {
        public Passenger(string name)
            : base(name)
        {
        }
    }
    public class Driver : IDName
    {
        public Fleet fleet; // if this driver is external then this value is null.
        public Location location; // For this sim, we don't care about initial location.  Driver's can magically get where they need to be.
        public DateTime routeStartTime;
        public Route route;
        public Driver(string name, Fleet fleet = null, Location location = null)
            : base(name)
        {
            if (fleet != null)
                fleet.AddDriver(this);
            this.fleet = fleet;
            this.location = location;
        }
        public override string ToString()
        {
            string s = name;
            if (location != null)
                s += "(@" + location + ")";
            if (route != null)
                s += ", Destination = " + route.end + ", ETA = " + (routeStartTime + route.duration);
            return s;
        }
    }
    public class Fleet : IDName
    {
        public Partner partner;
        public Location location;
        public List<Zone> coverage;
        public List<VehicleType> vehicleTypes;
        public Dictionary<string, Driver> drivers;
        public LinkedList<Driver> availableDrivers;
        public LinkedList<Driver> returningDrivers;

        public Fleet(string name, Location location, List<Zone> coverage, List<Driver> drivers, List<VehicleType> vehicleTypes, Partner partner = null)
            : base(name)
        {
            this.coverage = coverage;
            this.partner = partner;
            this.location = location;
            this.drivers = new Dictionary<string, Driver>();
            availableDrivers = new LinkedList<Driver>();
            returningDrivers = new LinkedList<Driver>();
            this.vehicleTypes = new List<VehicleType>(vehicleTypes);
            if (drivers != null)
            {
                foreach (Driver d in drivers)
                    AddDriver(d);
            }
            if (partner != null)
                partner.AddFleet(this);
        }
        public void AddDriver(Driver d)
        {
            d.fleet = this;
            d.location = location;
            drivers.Add(d.ID, d);
            availableDrivers.AddLast(d);
        }
        public void CompleteTrip(Trip t)
        {
            returningDrivers.AddLast(t.driver);
            t.driver.routeStartTime = DateTime.UtcNow;
            t.driver.route = partner.driverRoutes[partner.GetRouteKey(t.dropoffLocation, location)];
        }
        public bool Dispatch(Trip t)
        {
            if (t.status != Status.Queued)
                throw new Exception("Invalid 'Dispatch' status");
            if (availableDrivers.Count > 0)
            {
                t.driver = availableDrivers.First();
                t.fleet = this;
                availableDrivers.RemoveFirst();
                Logger.Log("Dispatched to " + t.driver.name);
                t.SetStatus(Status.Dispatched);
                return true;
            }
            return false;
        }
        public static implicit operator Gateway.GetPartnerInfo.Response.Fleet(Fleet f)  // explicit byte to digit conversion operator
        {
            return new Gateway.GetPartnerInfo.Response.Fleet(new IDName(f.partner.ID, f.partner.name), f, f.coverage);  // explicit conversion
        }

        // TODO: make these more real
        public double GetPrice(Trip trip)
        {
            return 20; // once we have the distance it won't be too hard to come up with some prices.
        }
        public double GetDistance(Trip trip)
        {
            return 20; // TODO: need to add this to the routes (requires regenerating the .cvs files)
        }
        public DateTime GetETA(Trip trip)
        {
            DateTime ETA = DateTime.UtcNow + partner.driverRoutes[partner.GetRouteKey(location, trip.pickupLocation)].duration;
            if (availableDrivers.Count == 0)
                ETA += new TimeSpan(3, 0, 0); // if there are no drivers avaialble we add 3 hrs.  TODO: make this more realistic
            if (trip.pickupTime > ETA)
                ETA = trip.pickupTime;
            return ETA; // TODO: for now all trips are picked up on time
        }
    }

    public class Partner : Gateway
    {
        public new class GetPartnerInfo : Gateway.GetPartnerInfo
        {
            public Partner partner;
            public GetPartnerInfo(Partner partner)
            {
                this.partner = partner;
            }
            public override Response Get(Request request)
            {
                List<VehicleType> vehicleTypes = new List<VehicleType>();
                foreach (Fleet f in partner.fleets.Values)
                    vehicleTypes.AddRange(f.vehicleTypes);
                List<Response.Fleet> fleets = new List<Response.Fleet>();
                foreach (Fleet f in partner.fleets.Values)
                    fleets.Add(f);
                Response response = new Response(fleets, vehicleTypes);
                Logger.Log("GetPartnerInfo called on " + partner.name + ": Response = " + response);
                return response;
            }
        }
        public new class DispatchTrip : Gateway.DispatchTrip
        {
            public Partner partner;
            public Trip GetTrip(Request r)
            {
                return new Trip(
                    partner: partner,
                    pickupLocation: r.pickupLocation, 
                    pickupTime: r.pickupTime, 
                    paymentMethod: r.paymentMethod, 
                    foreignID: r.foreignID,
                    passengerID: r.passengerID, 
                    passengerName: r.passengerName, 
                    dropoffLocation: r.dropoffLocation,
                    waypoints: r.waypoints, 
                    vehicleType: r.vehicleType, 
                    maxPrice: r.maxPrice, 
                    minRating: r.minRating, 
                    fleet: r.fleetID == null ? null : partner.fleets[r.fleetID], 
                    driver: r.driverID == null ? null : partner.fleets[r.fleetID].drivers[r.driverID]);
            }
            public DispatchTrip(Partner partner)
            {
                this.partner = partner;
            }
            public override Response Post(Request r)
            {
                // Note: GetTrip populates the foreignTripID
                int numAvailableDrivers = 0;
                foreach (Fleet f in partner.fleets.Values)
                    numAvailableDrivers += f.availableDrivers.Count;

                if (numAvailableDrivers == 0)
                {
                    Response response = new Response(result: Result.Rejected);
                    Logger.Log("DispatchTrip rejected on " + partner.name + ", no available drivers -- Response: " + response);
                    return response;
                }
                else
                {
                    Trip trip = GetTrip(r);
                    partner.QueueTrip(trip);
                    Response response = new Response(trip.ID);
                    Logger.Log("DispatchTrip successful on " + partner.name + ", Response: " + response);
                    return response;
                }
            }
        }
        public new class QuoteTrip : Gateway.QuoteTrip
        {
            public Trip GetTrip(Request r)
            {
                return new Trip(partner, r.pickupLocation, r.pickupTime, r.paymentMethod, r.passengerID, r.passengerName, r.dropoffLocation,
                    null, r.waypoints, r.vehicleType, r.maxPrice, r.minRating, r.fleetID == null ? null : partner.fleets[r.fleetID], r.driverID == null ? null : partner.fleets[r.fleetID].drivers[r.driverID]);
            }
            public Partner partner;
            public QuoteTrip(Partner partner)
            {
                this.partner = partner;
            }
            public override Response Get(Request r)
            {
                List<Response.Quote> quotes = new List<Response.Quote>();
                foreach (Fleet f in partner.fleets.Values)
                {
                    foreach (VehicleType vehicleType in f.vehicleTypes)
                    {
                        if (r.vehicleType == vehicleType || r.vehicleType == null)
                        {
                            Trip trip = GetTrip(r);
                            trip.vehicleType = vehicleType;
                            quotes.Add(new Response.Quote(
                                partnerID: partner.foreignID, 
                                partnerName: partner.name, 
                                fleetID: f.ID, fleetName: f.name, 
                                vehicleType: vehicleType, 
                                price: f.GetPrice(trip), 
                                distance: f.GetDistance(trip),
                                duration: trip.duration, 
                                ETA: f.GetETA(trip)));
                        }
                    }
                }
                Response response = new Response(quotes);
                Logger.Log("QuoteTrip called on " + partner.name + ", Response: " + response);
                return response;
            }
        }
        public new class GetTripStatus : Gateway.GetTripStatus
        {
            public Partner partner;
            public GetTripStatus(Partner partner)
            {
                this.partner = partner;
            }
            public override Response Get(Request r)
            {
                Trip t = partner.tripsByLocalID[r.tripID];
                DateTime? ETA = null;
                if (t.status == Status.Dispatched)
                    ETA = t.pickupTime;
                else if (t.status == Status.PickedUp)
                    ETA = t.pickupTime + new TimeSpan(0, 5, 0); // TODO: for now lets assume every trip takes 5 mins.
                DateTime? pickupTime = null;
                if (t.status == Status.PickedUp || t.status == Status.DroppedOff || t.status == Status.Complete)
                    pickupTime = t.pickupTime; // Only if trip has been pickedup.
                Response response = new Response(
                    partnerID: partner.ID, 
                    partnerName: partner.name, 
                    fleetID: t.fleet.ID, 
                    fleetName: t.fleet.name,
                    pickupTime: pickupTime,
                    driverID: t.driver.ID, 
                    driverName: t.driver.name, 
                    driverLocation: t.driver.location, 
                    dropoffTime: t.dropoffTime,
                    vehicleType: t.vehicleType,
                    ETA: ETA);
                Logger.Log("GetTripStatus called on " + partner.name + ", Response: " + response);
                return response;
            }
        }
        public new class UpdateTripStatus : Gateway.UpdateTripStatus
        {
            public Partner partner;
            public UpdateTripStatus(Partner partner)
            {
                this.partner = partner;
            }
            public override Response Post(Request r)
            {
                // Note: GetTrip populates the foreignTripID
                Trip t = partner.tripsByLocalID[r.tripID];
                Response response = new Response();
                Logger.Log("UpdateTripStatus called on " + partner.name + ", Response: " + response);
                Logger.Tab();
                t.SetStatus(r.status, notifyPartner: false);
                Logger.Untab();
                return response;
            }
        }
        public string ID;
        public string foreignID;
        public string name;
        public Dictionary<string, Fleet> fleets;
        public Passenger[] passengers;
        public double tripsPerHour;
        public Random random;
        public LinkedList<Trip> trips;
        public Dictionary<string, Route> driverRoutes;
        public Dictionary<string, Route> tripRoutes;
        public Dictionary<string, Trip> tripsByforeignID;
        public Dictionary<string, Trip> tripsByLocalID;
        public DateTime lastSim;
        public Gateway tripthru;
        // Configuration parameters
        public TimeSpan tripMaxAdvancedNotice = new TimeSpan(0, 0, 15); // minutes
        public TimeSpan simInterval = new TimeSpan(0, 0, 10);
        public TimeSpan updateInterval = new TimeSpan(0, 0, 30); // for simluation
        public TimeSpan missedPeriod = new TimeSpan(0, 1, 0);
        public TimeSpan criticalPeriod = new TimeSpan(0, 1, 0);
        public TimeSpan removalAge = new TimeSpan(0, 5, 0);

        static long nextID = 0;
        static public string GenerateUniqueID() { nextID++; return nextID.ToString(); }


        public Partner(Gateway tripthru, string name, double tripsPerHour, List<Route> tripRoutes, List<Route> driverRoutes, List<Passenger> passengers, List<Fleet> fleets = null)
        {
            this.tripthru = tripthru;
            this.foreignID = null; // will be populated upon registration.
            this.ID = GenerateUniqueID();
            this.name = name;
            this.tripsPerHour = tripsPerHour;
            this.passengers = passengers.ToArray();
            random = new Random();
            this.tripRoutes = new Dictionary<string, Route>();
            foreach (Route r in tripRoutes)
                this.tripRoutes.Add(GetRouteKey(r.start, r.end), r);

            this.driverRoutes = new Dictionary<string,Route>();
            foreach (Route r in driverRoutes)
                this.driverRoutes.Add(GetRouteKey(r.start, r.end), r);
            this.fleets = new Dictionary<string, Fleet>();
            if (fleets != null)
            {
                foreach (Fleet f in fleets)
                    AddFleet(f);
            }

            tripsByforeignID = new Dictionary<string, Trip>();
            tripsByLocalID = new Dictionary<string, Trip>();

            trips = new LinkedList<Trip>();


            getPartnerInfo = new GetPartnerInfo(this);
            dispatchTrip = new DispatchTrip(this);
            quoteTrip = new QuoteTrip(this);
            getTripStatus = new GetTripStatus(this);
            updateTripStatus = new UpdateTripStatus(this);
        }
        public void AddFleet(Fleet f)
        {
            f.partner = this;
            fleets.Add(f.ID, f);
        }
        public void QueueTrip(Trip t)
        {
            Logger.Log("Queueing " + t);
            trips.AddLast(t);
            if (t.foreignID != null)
                tripsByforeignID.Add(t.foreignID, t);
            tripsByLocalID.Add(t.ID, t);
        }
        public void RemoveTrip(Trip t)
        {
            if (t.foreignID != null)
                tripsByforeignID.Remove(t.foreignID);
            trips.Remove(trips.Find(t));
        }
        public void RemoveTrip(LinkedListNode<Trip> t)
        {
            if (t.Value.foreignID != null)
                tripsByforeignID.Remove(t.Value.foreignID);
            tripsByLocalID.Remove(t.Value.ID);
            trips.Remove(t);
        }
        public string GetRouteKey(Location start, Location end) { return start.getID() + ":" + end.getID(); }        // Daniel, you will need to implement this
        public Route GetDriverRoute(Location from, Location to)
        {
            string key = GetRouteKey(from, to);
            if (!driverRoutes.ContainsKey(key))
                driverRoutes.Add(key, new Route(MapTools.GetDirections(from, to)));
            return driverRoutes[key];

        }
        public Route GetTripRoute(Location from, Location to)
        {
            string key = GetRouteKey(from, to);
            if (!tripRoutes.ContainsKey(key))
                tripRoutes.Add(key, new Route(MapTools.GetDirections(from, to)));
            return tripRoutes[key];

        }

        //new Location(-121.761709, 37.36286)
        private void GenerateTrips()
        {
            if (trips.Count > 30)
                return;
            int numTripsToGenerate = (int)Math.Floor(simInterval.TotalHours * tripsPerHour);
            {
                // this handles fractional trips.
                double d = (simInterval.TotalHours * tripsPerHour) - (double)numTripsToGenerate;
                if (d > random.NextDouble())
                    numTripsToGenerate++;
            }
            if (numTripsToGenerate == 0)
                return;
            DateTime now = DateTime.UtcNow;

            Route[] tripRoutesPicker = tripRoutes.Values.ToArray();
            for (int n = 0; n < numTripsToGenerate; n++)
            {
                Passenger passenger = passengers[random.Next(passengers.Length - 1)];
                Route route = tripRoutesPicker[random.Next(tripRoutesPicker.Length - 1)];
                DateTime pickupTime = now + new TimeSpan(0, random.Next((int)tripMaxAdvancedNotice.TotalMinutes), 0);
                Logger.Log("Pickup request: " + passenger.name + " requests to be picked up at " + route.start + " on " + pickupTime + " and dropped off at " + route.end);
                Logger.Tab();
                Trip trip = new Trip(
                    partner: this,
                    passengerID: passenger.ID,
                    passengerName: passenger.name,
                    pickupLocation: route.start,
                    pickupTime: pickupTime,
                    dropoffLocation: route.end,
                    paymentMethod: PaymentMethod.Cash);
                QueueTrip(trip);
                Logger.Untab();
            }
        }
        // speed is miles per hour
        public void GetTripStatusFromForeignServiceProvider(Trip t)
        {
            if (DateTime.UtcNow > t.lastUpdate + updateInterval)
            {
                Logger.Log("Getting (Foreign) status of " + t);
                Logger.Tab();
                Gateway.GetTripStatus.Request request = new Gateway.GetTripStatus.Request(clientID: foreignID, tripID: t.foreignID);
                Gateway.GetTripStatus.Response response = tripthru.getTripStatus.Get(request);
                if (response.status != null)
                    t.SetStatus((Status)response.status, notifyPartner: false);
                if (response.driverName != null)
                    t.driver = new Driver(name: response.driverName, location: response.driverLocation);
                if (response.dropoffTime != null)
                    t.dropoffTime = response.dropoffTime;
                if (response.vehicleType != null)
                    t.vehicleType = response.vehicleType;
                Logger.Untab();
            }
        }

        private void ProcessQueue()
        {
            for (LinkedListNode<Trip> node = trips.First; node != null; )
            {
                Trip t = node.Value;
                LinkedListNode<Trip> next = node.Next;

                switch (t.status)
                {
                    case Status.Queued:
                    {
                        if (t.origination != Trip.Origination.Foreign)
                        {
                            if (DateTime.UtcNow > t.pickupTime + missedPeriod)
                            {
                                Logger.Log("Missed period reached: -- so cancel " + t);
                                Logger.Tab();
                                t.SetStatus(Status.Cancelled, notifyPartner: true);
                                Logger.Untab();
                                break;
                            }
                            if (t.foreignID != null) // means serviced through partner
                                break;
                        }
                        // If origination is foreign, then it means we're servicing the trip so we have to process it.
                        if (DateTime.UtcNow < t.pickupTime - criticalPeriod)
                            break;
                        Logger.Log("Ready for dispatch: " + t);
                        Logger.Tab();

                        foreach (Fleet f in fleets.Values)
                        {
                            if (f.Dispatch(t))
                                break;
                        }
                        if (t.status == Status.Queued)
                        {
                            Logger.Log("No local driver available so dispatch to TripThru ");
                            Logger.Tab();
                            Gateway.DispatchTrip.Request request = new Gateway.DispatchTrip.Request(
                                clientID: foreignID,
                                pickupLocation: t.pickupLocation,
                                pickupTime: t.pickupTime,
                                foreignID: t.ID,
                                passengerID: t.passengerID,
                                passengerName: t.passengerName,
                                luggage: t.luggage,
                                persons: t.persons,
                                dropoffLocation: t.dropoffLocation,
                                waypoints: t.waypoints,
                                paymentMethod: t.paymentMethod,
                                vehicleType: t.vehicleType,
                                maxPrice: t.maxPrice,
                                minRating: t.minRating);
                            Gateway.DispatchTrip.Response response = tripthru.dispatchTrip.Post(request);
                            if (response.result == Result.OK)
                            {
                                t.foreignID = response.tripID;
                                // Actually, at this point its just in the partner's queue, until its dispatch to the partner's drivers -- so no status update. 
                                Logger.Log("Trip was successfully dispatched through TripThru: ForeignID = " + t.foreignID);
                            }
                            else
                                Logger.Log("Trip was rejected by TripThru");
                            Logger.Untab();
                        }
                        Logger.Untab();
                        break;
                    }
                    case Status.Dispatched:
                    {
                        if (t.foreignID != null && t.origination != Trip.Origination.Foreign)
                            GetTripStatusFromForeignServiceProvider(t);

                        else if (DateTime.UtcNow >= t.pickupTime - driverRoutes[GetRouteKey(t.fleet.location, t.pickupLocation)].duration)
                        {
                            Logger.Log("Driver enroute: " + t);
                            Logger.Tab();
                            t.driver.route = driverRoutes[GetRouteKey(t.fleet.location, t.pickupLocation)];
                            if (t.driver.route == null)
                                throw new Exception("fatal error");
                            t.driver.routeStartTime = DateTime.UtcNow;
                            t.SetStatus(Status.Enroute);
                            Logger.Untab();
                        }
                        else if (DateTime.UtcNow > t.lastUpdate + updateInterval)
                            Logger.Log("Getting status of: " + t);
                        break;
                    }
                    case Status.Enroute:
                    {
                        if (t.foreignID != null && t.origination != Trip.Origination.Foreign)
                            GetTripStatusFromForeignServiceProvider(t);
                        else
                        {
                            t.driver.location = t.driver.route.GetCurrentWaypoint(t.driver.routeStartTime, DateTime.UtcNow);
                            if (t.driver.location.Equals(t.pickupLocation))
                            {
                                Logger.Log("Picking up: " + t);
                                Logger.Tab();
                                t.driver.route = GetTripRoute(t.pickupLocation, t.dropoffLocation);
                                t.driver.routeStartTime = DateTime.UtcNow;
                                t.SetStatus(Status.PickedUp);
                                Logger.Untab();
                            }
                            else if (DateTime.UtcNow > t.lastUpdate + updateInterval)
                                Logger.Log("Getting status of: " + t);
                        }
                        break;
                    }
                    case Status.PickedUp:
                    {
                        if (t.foreignID != null && t.origination != Trip.Origination.Foreign)
                            GetTripStatusFromForeignServiceProvider(t);
                        else
                        {
                            Route route = GetTripRoute(t.pickupLocation, t.dropoffLocation);
                            t.driver.location = t.driver.route.GetCurrentWaypoint(t.driver.routeStartTime, DateTime.UtcNow);
                            if (t.driver.location == route.end)
                            {
                                Logger.Log("The destination has been reached for: " + t);
                                Logger.Tab();
                                t.dropoffTime = DateTime.UtcNow;
                                t.driver.fleet.CompleteTrip(t);
                                t.SetStatus(Status.Complete);
                                Logger.Untab();
                            }
                            else if (DateTime.UtcNow > t.lastUpdate + updateInterval)
                                Logger.Log("Getting status of: " + t);

                        }
                        break;
                    }
                    case Status.Cancelled:
                    {
                        TimeSpan age = DateTime.UtcNow - (DateTime)t.pickupTime;
                        if (age > removalAge) // for now we use 1 minute.
                        {
                            Logger.Log("Since old, remove: " + t);
                            RemoveTrip(node); // remove trips that are more than 1 day old.
                        }
                        break;
                    }
                    case Status.Complete:
                    {
                        if (t.dropoffTime == null)
                            GetTripStatusFromForeignServiceProvider(t);
                        TimeSpan age = DateTime.UtcNow - (DateTime)t.dropoffTime;
                        if (age > removalAge) // for now we use 1 minute.
                        {
                            Logger.Log("Since old, remove: " + t);
                            RemoveTrip(node); // remove trips that are more than 1 day old.
                        }
                        break;
                    }
                }
                node = next;
            }

        }

        public override void Simulate(DateTime until)
        {
            if (DateTime.UtcNow < lastSim + simInterval)
                return;

            if (foreignID == null)
            {
                RegisterPartner.Response response = tripthru.registerPartner.Post(new RegisterPartner.Request(
                    clientID: "sandbox", // TODO: Daniel, fix when you add authentication
                    name: name, 
                    callback_url: this));
                foreignID = response.partnerID;
            }
            GenerateTrips();
            ProcessQueue();
            foreach (Fleet f in fleets.Values)
            {
                for (LinkedListNode<Driver> node = f.returningDrivers.First; node != null; )
                {
                    Driver driver = node.Value;
                    LinkedListNode<Driver> next = node.Next;

                    driver.location = driver.route.GetCurrentWaypoint(driver.routeStartTime, DateTime.UtcNow);
                    if (driver.location == f.location)
                    {
                        Logger.Log("Driver " + driver.name + " has reached the home office ");
                        f.returningDrivers.Remove(node); 
                        f.availableDrivers.AddLast(driver);
                    }
                }

            }
            lastSim = DateTime.UtcNow;
        }
    }

}

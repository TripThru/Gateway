﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System.Diagnostics;
using System.Web;
using System.Xml;
using System.Xml.XPath;
using APIs;

namespace Utils
{
    public class Waypoint : Location
    {
        public Waypoint(double lat, double lng, TimeSpan elapse, string name = null)
            : base(lat, lng, name)
        {
            this.elapse = elapse;
        }
        public Waypoint(Location l, TimeSpan elapse, string name = null)
            : base(l.lat, l.lng, name)
        {
            this.elapse = elapse;
        }
        public TimeSpan elapse;
    }
    public class Route
    {
        public Route()
        {
            waypointList = new List<Waypoint>();
        }
        public Route(Waypoint[] waypoints)
        {
            this.waypoints = waypoints;
        }
        public void Initialize()
        {
            waypoints = waypointList.ToArray();
            waypointList = null;
        }
        public Location start { get { return waypoints[0]; } }
        public Location end { get { return waypoints[waypoints.Length - 1]; } }
        public TimeSpan duration { get { return waypoints[waypoints.Length - 1].elapse; } }
        public Location GetCurrentWaypoint(DateTime start, DateTime current)
        {
            TimeSpan elapse = current - start;
            int waypoint;
            for (waypoint = 0; elapse > waypoints[waypoint].elapse && waypoint < waypoints.Length - 1; waypoint++) ;
            return waypoints[waypoint];
        }
        public List<Waypoint> waypointList;
        public Waypoint[] waypoints;
    }
    public class IDName
    {
        public string ID;
        public string name;
        public IDName(string ID, string name)
        {
            this.ID = ID;
            this.name = name;
        }
        public IDName(string name)
        {
            this.ID = GenerateUniqueID();
            this.name = name;
        }
        public IDName()
        {
            this.ID = null;
            this.name = null;
        }
        public override string ToString()
        {
            return "(ID = " + ID + ", Name = " + name + ")";
        }

        static long nextID = 0;
        static public string GenerateUniqueID() { nextID++; return nextID.ToString(); }
    }

    class MapTools
    {

        // http://code.google.com/apis/maps/documentation/geocoding/#ReverseGeocoding
        public static string GetReverseGeoLoc(Location location)
        {
            XmlDocument doc = new XmlDocument();
            {
                doc.Load("http://maps.googleapis.com/maps/api/geocode/xml?latlng=" + location.lat + "," + location.lng + "&sensor=false");
                XmlNode element = doc.SelectSingleNode("//GeocodeResponse/status");
                if (element.InnerText == "OVER_QUERY_LIMIT")
                {
                    System.Threading.Thread.Sleep(new TimeSpan(0, 1, 10));
                    doc.Load("http://maps.googleapis.com/maps/api/geocode/xml?latlng=" + location.lat + "," + location.lng + "&sensor=false");
                    element = doc.SelectSingleNode("//GeocodeResponse/status");

                }
                if (element.InnerText == "ZERO_RESULTS" || element.InnerText == "OVER_QUERY_LIMIT")
                    return null;
                else
                {

                    element = doc.SelectSingleNode("//GeocodeResponse/result/formatted_address");
                    return element.InnerText;
                }
            }
        }
        // http://maps.googleapis.com/maps/api/directions/json?origin=Toronto&destination=Montreal&sensor=false
        public static Waypoint[] GetDirections(Location from, Location to)
        {
            XmlDocument doc = new XmlDocument();
            TimeSpan elapse = new TimeSpan(0, 0, 0);
            string url = "http://maps.googleapis.com/maps/api/directions/xml?origin=" + from.lat + ", " + from.lng + "&destination=" + to.lat + ", " + to.lng + "&sensor=false";
            doc.Load(url);
            XmlNode status = doc.SelectSingleNode("//DirectionsResponse/status");
            if (status == null || status.InnerText == "ZERO_RESULTS")
                return null;
            List<Waypoint> waypoints = new List<Waypoint>();
            waypoints.Add(new Waypoint(from, new TimeSpan(0)));
            var legs = doc.SelectNodes("//DirectionsResponse/route/leg");
            foreach (XmlNode leg in legs)
            {
                var stepNodes = leg.SelectNodes("step");
                foreach (XmlNode stepNode in stepNodes)
                {
                    TimeSpan duration = new TimeSpan(0, 0, int.Parse(stepNode.SelectSingleNode("duration/value").InnerText));
                    Location end = new Location(double.Parse(stepNode.SelectSingleNode("end_location/lat").InnerText), double.Parse(stepNode.SelectSingleNode("end_location/lng").InnerText));
                    elapse += duration;
                    waypoints.Add(new Waypoint(end, elapse));
                }
            }
            waypoints.Add(new Waypoint(to, elapse));
            return waypoints.ToArray();
        }
    }

    public class Logger
    {
        static int tab;
        public static int logLine;
        public static bool enabled { get; set; }
        public static bool forceOn { get; set; }
        public static string filePath = "c:\\";
        static int on;
        static System.IO.StreamWriter logFile;
        //        [Conditional("DEBUG")]
        static public void Tab() { tab++; }
        //        [Conditional("DEBUG")]
        static public void Untab() { tab--; }
        static public string GetTab()
        {
            string tabs = "";
            for (int n = 0; n < tab; n++)
                tabs += '\t';
            //                tabs += "-----";
            return tabs;
        }
        static public void Off()
        {
            on--;
        }
        static public void On()
        {
            on++;
        }

        static public void Log(string msg, string filename)
        {
            if (filename.Length == 0)
            {
                Log(msg);
                return;
            }
            OpenLog(filename, true, true);
            logFile.WriteLine(GetTab() + msg);
            logFile.Flush();
            CloseLog();
        }
        [Conditional("DEBUG")]
        static public void Log(string msg)
        {
            {
                if (logFile == null)
                    return;
                if (!enabled && !forceOn)
                    return;
            }
            logFile.WriteLine(GetTab() + msg);
            logFile.Flush();
        }
        static public void OpenLog(string filename, bool enabled_, bool append = false)
        {
            if (!append)
            {
                tab = 0;
                logLine = 0;
                forceOn = false;
                enabled = enabled_;
            }
            enabledMethods = new LinkedList<string>();
            logFile = new System.IO.StreamWriter("c:\\Users\\Edward\\" + filename);
            //logFile = new System.IO.StreamWriter(filePath + filename, append);
        }

        static public void CloseLog()
        {
            logFile.Close();
            logFile = null;
        }
        static public LinkedList<string> enabledMethods;
    }
}

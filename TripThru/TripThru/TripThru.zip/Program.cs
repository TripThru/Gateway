﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

// Local
using APIs;
using Simulations;
using tripThru;
using Utils;

namespace Program
{
    class Program
    {
        static void Main(string[] args)
        {
            TripThru tripthru = new TripThru();
            List<Partner> partners = new List<Partner>();
            List<Route> tripRoutes = Simulator.LoadTripRoutes("SimTripRoutes.csv");
            Location One_Post_St_San_Francisco_CA = new Location(37.78906, -122.402127);
            //Simulator.WriteDriverRoutes(One_Post_St_San_Francisco_CA, tripRoutes);
            List<Route> driverRoutes = Simulator.LoadDriverRoutes("SimDriverRoutes.csv");





            // These are just random routes for simulation to pick from
            List<Passenger> passengers = new List<Passenger>();
            passengers.Add(new Passenger("Elvis Presley"));
            passengers.Add(new Passenger("John Riggins"));
            passengers.Add(new Passenger("Bart Star"));
            passengers.Add(new Passenger("Michelle Phieffer"));
            passengers.Add(new Passenger("Zong Zi Yi"));
            passengers.Add(new Passenger("Mickey Rourke"));

            List<VehicleType> vehicleTypes = new List<VehicleType>();
            vehicleTypes.Add(VehicleType.Compact);
            vehicleTypes.Add(VehicleType.Sedan);

            Zone zoneSanFrancisco = new Zone(One_Post_St_San_Francisco_CA, 50);
            Zone zoneAnywhere = new Zone(One_Post_St_San_Francisco_CA, double.MaxValue);
            {
                List<Fleet> fleets = new List<Fleet>();
                {
                    List<Driver> drivers = new List<Driver>();
                    drivers.Add(new Driver("Daniel Corona"));
                    drivers.Add(new Driver("Edward Hamilton"));
                    drivers.Add(new Driver("Joanna Glennon"));
                    List<Zone> coverage = new List<Zone>();
                    coverage.Add(zoneAnywhere);
                    fleets.Add(new Fleet("Anywhere #1", One_Post_St_San_Francisco_CA, coverage, drivers, vehicleTypes));
                }
                partners.Add(new Partner(tripthru: tripthru, 
                    name: "Anywhere #1", tripsPerHour: 300, 
                    tripRoutes: tripRoutes, 
                    driverRoutes: driverRoutes, 
                    passengers: passengers, 
                    fleets: fleets));
            }
            {
                List<Fleet> fleets = new List<Fleet>();
                {
                    List<Driver> drivers = new List<Driver>();
                    drivers.Add(new Driver("Eduardo Lozano"));
                    drivers.Add(new Driver("Mark Glennon"));
                    drivers.Add(new Driver("James Katic"));
                    drivers.Add(new Driver("Ofer Matan"));
                    drivers.Add(new Driver("Geoff Chappel"));
                    drivers.Add(new Driver("Steven Thompson"));

                    List<Zone> coverage = new List<Zone>();
                    coverage.Add(zoneAnywhere);
                    fleets.Add(new Fleet("Anywhere #2", One_Post_St_San_Francisco_CA, coverage, drivers, vehicleTypes));
                }
                partners.Add(new Partner(tripthru: tripthru, 
                    name: "Anywhere #2", tripsPerHour: 20,
                    tripRoutes: tripRoutes, driverRoutes: driverRoutes, passengers: passengers, fleets: fleets));
            }

            Simulate(partners, DateTime.UtcNow + new TimeSpan(0, 10, 0));
        }
        public static void Simulate(List<Partner> partners, DateTime until)
        {
            Logger.OpenLog("TripThruSimulation.log", true);
            Logger.Log("Simulating from " + DateTime.UtcNow + " until " + until.ToString());
            Logger.Tab();
            TimeSpan simInterval = new TimeSpan(0, 0, 10);
            while (DateTime.UtcNow < until)
            {
                Logger.Log("Time = " + DateTime.UtcNow);
                Logger.Tab();
                foreach (Partner p in partners)
                    p.Simulate(until);
                System.Threading.Thread.Sleep(simInterval);
                Logger.Untab();
            }
            Logger.Untab();

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System.IO;
using System.Globalization;
using APIs;
using Utils;
using tripThru;

namespace Simulations
{
    /// <summary>
    /// Class to store one CSV row
    /// </summary>
    public class CsvRow : List<string>
    {
        public string LineText { get; set; }
    }
    /// <summary>
    /// Class to write data to a CSV file
    /// </summary>
    public class CsvFileWriter : StreamWriter
    {
        public CsvFileWriter(Stream stream)
            : base(stream)
        {
        }

        public CsvFileWriter(string filename)
            : base(filename)
        {
        }

        /// <summary>
        /// Writes a single row to a CSV file.
        /// </summary>
        /// <param name="row">The row to be written</param>
        public void WriteRow(CsvRow row)
        {
            StringBuilder builder = new StringBuilder();
            bool firstColumn = true;
            foreach (string value in row)
            {
                // Add separator if this isn't the first value
                if (!firstColumn)
                    builder.Append(',');
                // Implement special handling for values that contain comma or quote
                // Enclose in quotes and double up any double quotes
                if (value.IndexOfAny(new char[] { '"', ',' }) != -1)
                    builder.AppendFormat("\"{0}\"", value.Replace("\"", "\"\""));
                else
                    builder.Append(value);
                firstColumn = false;
            }
            row.LineText = builder.ToString();
            WriteLine(row.LineText);
        }
    }


    /// <summary>
    /// Class to read data from a CSV file
    /// </summary>
    public class CsvFileReader : StreamReader
    {
        public CsvFileReader(Stream stream)
            : base(stream)
        {
        }

        public CsvFileReader(string filename)
            : base(filename)
        {
        }

        /// <summary>
        /// Reads a row of data from a CSV file
        /// </summary>
        /// <param name="row"></param>
        /// <returns></returns>
        public bool ReadRow(CsvRow row, char separator)
        {
            row.LineText = ReadLine();
            if (String.IsNullOrEmpty(row.LineText))
                return false;

            int pos = 0;
            int rows = 0;

            while (pos < row.LineText.Length)
            {
                string value;

                // Special handling for quoted field
                if (row.LineText[pos] == '"')
                {
                    // Skip initial quote
                    pos++;

                    // Parse quoted value
                    int start = pos;
                    while (pos < row.LineText.Length)
                    {
                        // Test for quote character
                        if (row.LineText[pos] == '"')
                        {
                            // Found one
                            pos++;

                            // If two quotes together, keep one
                            // Otherwise, indicates end of value
                            if (pos >= row.LineText.Length || row.LineText[pos] != '"')
                            {
                                pos--;
                                break;
                            }
                        }
                        pos++;
                    }
                    value = row.LineText.Substring(start, pos - start);
                    value = value.Replace("\"\"", "\"");
                }
                else
                {
                    // Parse unquoted value
                    int start = pos;
                    while (pos < row.LineText.Length && row.LineText[pos] != separator)
                        pos++;
                    value = row.LineText.Substring(start, pos - start);
                }

                // Add field to list
                if (rows < row.Count)
                    row[rows] = value;
                else
                    row.Add(value);
                rows++;

                // Eat up to and including next comma
                while (pos < row.LineText.Length && row.LineText[pos] != separator)
                    pos++;
                if (pos < row.LineText.Length)
                    pos++;
            }
            // Delete any unused items
            while (row.Count > rows)
                row.RemoveAt(rows);

            // Return true if any columns read
            return (row.Count > 0);
        }
    }

    class Simulator
    {
        public static string GetRouteID(Location from, Location to)
        {
            return "[" + from.lat + "|" + from.lng + ":" + to.lat + "|" + to.lng + "]";
        }
        public static List<Route> LoadTripRoutes(string filename)
        {
            // Read sample data from CSV file
            Dictionary<long, Route> routes = new Dictionary<long, Route>();
            using (CsvFileReader reader = new CsvFileReader(filename))
            {
                CsvRow row = new CsvRow();
                while (reader.ReadRow(row, ','))
                {
                    long routeID = Convert.ToInt64(row[0]);
                    Waypoint waypoint = new Waypoint(Convert.ToDouble(row[2]), Convert.ToDouble(row[1]), TimeSpan.Parse(row[3]), row[4].Replace("\"", ""));

                    // Scenario #1
                    if (!routes.ContainsKey(routeID))
                        routes[routeID] = new Route();
                    routes[routeID].waypointList.Add(waypoint);

                }
            }
            foreach (Route r in routes.Values)
                r.Initialize();
            return new List<Route>(routes.Values);
        }
        public static List<Route> LoadDriverRoutes(string filename)
        {
            // Read sample data from CSV file
            Dictionary<string, Route> routes = new Dictionary<string, Route>();
            using (CsvFileReader reader = new CsvFileReader(filename))
            {
                CsvRow row = new CsvRow();
                while (reader.ReadRow(row, ','))
                {
                    string routeID = row[0];
                    Waypoint waypoint = new Waypoint(Convert.ToDouble(row[1]), Convert.ToDouble(row[2]), TimeSpan.Parse(row[3]), row[4].Replace("\"", ""));

                    // Scenario #1
                    if (!routes.ContainsKey(routeID))
                        routes[routeID] = new Route();
                    routes[routeID].waypointList.Add(waypoint);

                }
            }
            foreach (Route r in routes.Values)
                r.Initialize();
            return new List<Route>(routes.Values);
        }

        public static void WriteDriverRoutes(Location office, List<Route> tripRoutes)
        {
            using (CsvFileWriter writer = new CsvFileWriter("SimDriverRoutes.csv"))
            {
                foreach (Route r in tripRoutes)
                {
                    {
                        Waypoint[] waypoints = MapTools.GetDirections(office, r.start);
                        string routeID = GetRouteID(office, r.start);
                        foreach (Waypoint w in waypoints)
                        {
                            CsvRow row = new CsvRow();
                            //                row.Add(trip.id.ToString());
                            //                row.Add(trip.startTime.ToString());
                            row.Add(routeID);
                            row.Add(w.lat.ToString());
                            row.Add(w.lng.ToString());
                            row.Add(w.elapse.ToString());
                            row.Add(w.name);
                            writer.WriteRow(row);
                        }
                    }
                    {
                        Waypoint[] waypoints = MapTools.GetDirections(r.end, office);
                        string routeID = GetRouteID(r.end, office);
                        foreach (Waypoint w in waypoints)
                        {
                            CsvRow row = new CsvRow();
                            //                row.Add(trip.id.ToString());
                            //                row.Add(trip.startTime.ToString());
                            row.Add(routeID);
                            row.Add(w.lat.ToString());
                            row.Add(w.lng.ToString());
                            row.Add(w.elapse.ToString());
                            row.Add(w.name);
                            writer.WriteRow(row);
                        }
                    }
                }
            }
        }
        public void Run(List<Partner> partners, DateTime until)
        {
            Logger.OpenLog("TripThruSimulation.log", true);
            Logger.Log("Simulating from " + DateTime.UtcNow + " until " + until.ToString());
            Logger.Tab();
            TimeSpan simInterval = new TimeSpan(0, 0, 10);
            while (DateTime.UtcNow < until)
            {
                Logger.Log("Heartbeat at " + DateTime.UtcNow);
                Logger.Tab();
                foreach (Partner p in partners)
                    p.Simulate(until);
                System.Threading.Thread.Sleep(simInterval);
                Logger.Untab();
            }
            Logger.Untab();

        }


    }
}
